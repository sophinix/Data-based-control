function smallplot(signal1,signal2,signal3,x,y,width,length)
% rectangle('Position', [x, y, width, length], 'EdgeColor',"m", 'LineWidth', 1);
ms=max(size(signal1));
st=0.0625;%毫秒
time=(0:ms-1)*st;
ax1 = axes('Position',[0.222,0.815+0.026,0.25,0.11]);   % 小图 设置小图的大小和位置（左上角位置+宽高）
plot(time,signal1,'color','r','LineWidth',1.2)
hold on
plot(time,signal2,'color','blue','LineWidth',1.8, 'LineStyle', ':')
hold on 
plot(time,signal3,'color','black','LineWidth',1.6, 'LineStyle', '--')
set(gca,'Xlim',[x,x+width]);
set(gca,'ylim',[y,y+length]);
grid on
