%bff
A1=importdata('bff_tra1.txt');
B1=A1.data;
tra1_bff_feedforward=B1(8:266+7,4);

A2=importdata('bff_tra2.txt');
B2=A2.data;
tra2_bff_feedforward=B2(8:300+7,4);

A3=importdata('bff_tra3.txt');
B3=A3.data;
tra3_bff_feedforward=B3(8:257+7,4);

A4=importdata('bff_tra4.txt');
B4=A4.data;
tra4_bff_feedforward=B4(8:366+7,4);

A5=importdata('bff_tra5.txt');
B5=A5.data;
tra5_bff_feedforward=B5(8:528+7,4);

%ff
A1=importdata('ff_tra1.txt');
B1=A1.data;
tra1_ff_feedforward=B1(8:266+7,4);


A2=importdata('ff_tra2.txt');
B2=A2.data;
tra2_ff_feedforward=B2(8:300+7,4);

A3=importdata('ff_tra3.txt');
B3=A3.data;
tra3_ff_feedforward=B3(8:257+7,4);

A4=importdata('ff_tra4.txt');
B4=A4.data;
tra4_ff_feedforward=B4(8:366+7,4);

A5=importdata('ff_tra5.txt');
B5=A5.data;
tra5_ff_feedforward=B5(8:528+7,4);

%ff
A1=importdata('ffdob_tra1.txt');
B1=A1.data;
tra1_ffdob_feedforward=B1(8:266+7,4);

A2=importdata('ffdob_tra2.txt');
B2=A2.data;
tra2_ffdob_feedforward=B2(8:300+7,4);

A3=importdata('ffdob_tra3.txt');
B3=A3.data;
tra3_ffdob_feedforward=B3(8:257+7,4);

A4=importdata('ffdob_tra4.txt');
B4=A4.data;
tra4_ffdob_feedforward=B4(8:366+7,4);

A5=importdata('ffdob_tra5.txt');
B5=A5.data;
tra5_ffdob_feedforward=B5(8:528+7,4);


% titlesize=12;
% labelsize=12;
% figure(1)
% subplot(5,1,1)
% feedforwardplot(tra1_bff_feedforward,tra1_ffdob_feedforward,tra1_ff_feedforward,[109,162])
% legend('M3','M2','M1','Orientation', 'horizontal','fontsize',11)
% h=title('(a) Feedforward signal with Trajecoty 1','Interpreter','latex' ,'fontsize',titlesize);
% set(h, 'Units', 'normalized', 'Position', [0.5, -0.35, 0]);
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% rectangle('Position', [6.5,-1100,0.5,2000], 'EdgeColor',"m", 'LineWidth', 1);
% rectangle('Position', [10,-3400,0.5,4200], 'EdgeColor',"m", 'LineWidth', 1);
% smallplot(tra1_bff_feedforward,tra1_ffdob_feedforward,tra1_ff_feedforward,6.5,-1100,0.5,2000)
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra1_bff_feedforward,tra1_ffdob_feedforward,tra1_ff_feedforward,10,-3400,0.5,4200)
% 
% subplot(5,1,2)
% feedforwardplot(tra2_bff_feedforward,tra2_ffdob_feedforward,tra2_ff_feedforward,[105,203])
% h=title('(b) Feedforward signal with Trajecoty 2','Interpreter','latex' ,'fontsize',titlesize);
% set(h, 'Units', 'normalized', 'Position', [0.5, -0.35, 0]);
% rectangle('Position', [6.3,-1300,0.5,2000], 'EdgeColor',"m", 'LineWidth', 1);
% rectangle('Position', [12.4,-3200,0.5,3800], 'EdgeColor',"m", 'LineWidth', 1);
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra2_bff_feedforward,tra2_ffdob_feedforward,tra2_ff_feedforward,6.3,-1300,0.5,2000)
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra2_bff_feedforward,tra2_ffdob_feedforward,tra2_ff_feedforward,12.4,-3200,0.5,3800)
% 
% subplot(5,1,3)
% feedforwardplot2(tra3_bff_feedforward,tra3_ffdob_feedforward,tra3_ff_feedforward,[101,164])
% h=title('(c) Feedforward signal with Trajecoty 3','Interpreter','latex' ,'fontsize',titlesize);
% set(h, 'Units', 'normalized', 'Position', [0.5, -0.35, 0]);
% rectangle('Position', [6.3,-3000,0.5,3800], 'EdgeColor',"m", 'LineWidth', 1);
% rectangle('Position', [10,-3400,0.5,4000], 'EdgeColor',"m", 'LineWidth', 1);
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra3_bff_feedforward,tra3_ffdob_feedforward,tra3_ff_feedforward,6.3,-3000,0.5,3800)
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra3_bff_feedforward,tra3_ffdob_feedforward,tra3_ff_feedforward,10,-3400,0.5,4000)
% 
% subplot(5,1,4)
% feedforwardplot(tra4_bff_feedforward,tra4_ffdob_feedforward,tra4_ff_feedforward,[109,162])
% h=title('(d) Feedforward signal with Trajecoty 4','Interpreter','latex' ,'fontsize',titlesize);
% set(h, 'Units', 'normalized', 'Position', [0.5, -0.35, 0]);
% rectangle('Position', [6.5,-1500,0.5,3200], 'EdgeColor',"m", 'LineWidth', 1);
% rectangle('Position', [9.85,-3000,0.5,4000], 'EdgeColor',"m", 'LineWidth', 1);
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra4_bff_feedforward,tra4_ffdob_feedforward,tra4_ff_feedforward,6.5,-1500,0.5,3200)
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra4_bff_feedforward,tra4_ffdob_feedforward,tra4_ff_feedforward,9.85,-3000,0.5,4000)
% 
% subplot(5,1,5)
% feedforwardplot(tra5_bff_feedforward,tra5_ffdob_feedforward,tra5_ff_feedforward,[162,366])
% h=title('(e) Feedforward signal with Trajecoty 5','Interpreter','latex' ,'fontsize',titlesize);
% set(h, 'Units', 'normalized', 'Position', [0.5, -0.35, 0]);
% rectangle('Position', [9.9,-3500,0.5,4100], 'EdgeColor',"m", 'LineWidth', 1);
% rectangle('Position', [22.6,-1700,0.5,3400], 'EdgeColor',"m", 'LineWidth', 1);
% xlabel('Time ($\mathrm{ms}$)','Interpreter','latex' ,'fontsize',labelsize);
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra5_bff_feedforward,tra5_ffdob_feedforward,tra5_ff_feedforward,9.9,-3500,0.5,4100)
% annotation('arrow',[0.54 0.54+0.0663],[0.803+0.028 0.803+0.01+0.028],'color',"m",'LineWidth',1.5);
% smallplot(tra5_bff_feedforward,tra5_ffdob_feedforward,tra5_ff_feedforward,22.6,-1700,0.5,3400)
