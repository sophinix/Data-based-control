function feedforwardplot(error1,error2,error3,s1)
ms=max(size(error1));
st=0.0625;%毫秒
time=(0:ms-1)*st;
plot(time,error1,'color','r','LineWidth',1.2)
hold on
plot(time,error2,'color','blue','LineWidth',1.8, 'LineStyle', ':')
hold on 
plot(time,error3,'color','black','LineWidth',1.6, 'LineStyle', '--')
sizes=size(s1,2);
for index=1:sizes
xline(s1(index)*st, 'color','[0.6350 0.0780 0.1840]','LineStyle','--','LineWidth',1.4);
end
ylabel('$u_{\mathrm{ff}}$ ','Interpreter','latex' ,'fontsize',14);
set(gca,'xLim',[0 ms]*st);
legend('off')
grid on