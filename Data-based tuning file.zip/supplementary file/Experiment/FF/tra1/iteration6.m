A1=importdata('61.txt');
B1=A1.data;
fol_err1=B1(8:273,4);

A2=importdata('62.txt');
B2=A2.data;
fol_err2=B2(8:273,4);
act_pos2=B2(8:273,3);

j1=CostComputation(fol_err1');
j2=CostComputation(fol_err2');
costj=[j1;j2;(j1+j2)/2];

A3=importdata('63.txt');
B3=A3.data;
act_pos3=B3(8:273,3);

Y1=timeseries(act_pos2,time);
Y2=timeseries(act_pos3,time);

    syscf=tf([1,0],[P1,P2,P3+D,P,I]);
    sysdcf=c2d(syscf,0.0000625);
    cfn=sysdcf.Numerator{1,1};
    cfd=sysdcf.Denominator{1,1};
model='data_processing';
sim(model);
dy=ans.dY(1:N,:);
R=(dy'*dy)/N;
invR=pinv(R);
dj=-dy'*fol_err1/N;
k=1;
site=[P2;P3];
site1=site-k*invR*dj;
P2=site1(1);
P3=site1(2);

Gn=tf(1,[P1,P2,P3]);
Fr=1/Gn;
FrQ1=Fr*Q1;
FrQ1=c2d(FrQ1,0.0000625,'tustin');
[num_FrQ1,den_FrQ1]=tfdata(FrQ1,'v');


