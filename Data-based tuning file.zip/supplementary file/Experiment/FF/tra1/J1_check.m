A1=importdata('71.txt');
B1=A1.data;
fol_err1=B1(8:273,4);

A2=importdata('72.txt');
B2=A2.data;
fol_err2=B2(8:273,4);

J_1=CostComputation(fol_err1');
J_2=CostComputation(fol_err2');
aa=[J_1;J_2]
J1_1=CostComputation(fol_err1(1:109)');
J1_2=CostComputation(fol_err2(1:109)');
aa1=[J1_1;J1_2]
