fprintf('Motor[1].Servo.Ka4= %.9g\n', site1(1))
fprintf('Motor[1].Servo.Ka5= %.9g\n', site1(2))
fprintf('Motor[1].Servo.Ka6= %.9g\n', site1(3))
