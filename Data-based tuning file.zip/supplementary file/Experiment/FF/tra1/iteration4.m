A1=importdata('41.txt');
B1=A1.data;
fol_err1=B1(8:7+N,4);

A2=importdata('42.txt');
B2=A2.data;
fol_err2=B2(8:7+N,4);
act_pos2=B2(8:7+N,3);

j1=CostComputation(fol_err1');
j2=CostComputation(fol_err2');
costj=[j1;j2;(j1+j2)/2];

Y1=timeseries(act_pos2,time);

    syscf=tf([1,0],[P1,P2,P3+D,P,I]);
    sysdcf=c2d(syscf,0.0000625);
    cfn=sysdcf.Numerator{1,1};
    cfd=sysdcf.Denominator{1,1};
model='data_processing';
sim(model);
dy=ans.dY(1:N,:);
R=(dy'*dy)/N;
invR=pinv(R);
dj=-dy'*fol_err1/N;
k=1;
site=[P1;P2;P3];
site1=site-k*invR*dj;
P1=site1(1);
P2=site1(2);
P3=site1(3);
