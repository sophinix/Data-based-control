P4=P1;
P5=P2;
P6=P3;
P7=P1;
P8=P2;
P9=P3;

A1=importdata('81.txt');
B1=A1.data;
fol_err1=B1(8:273,4); %根据采样点范围，截取266个点，对应参考轨迹长度
time=B1(2:267,1); %第一个点时间是0
J=fol_err1'*fol_err1/NN;
J1=fol_err1(1:n1)'*fol_err1(1:n1)/n1;

%exp2 s1y1
A2=importdata('52.txt');
B2=A2.data;
act_pos2=B2(7:272,3);
%exp3 s1y1
A3=importdata('53.txt');
B3=A3.data;
act_pos3=B3(7:272,3);
%exp4 s1y2
A4=importdata('54.txt');
B4=A4.data;
act_pos4=B4(8:273,3);
%exp5 s2y2
A5=importdata('55.txt');
B5=A5.data;
act_pos5=B5(8:273,3);

Y2=timeseries(act_pos2,time);
Y3=timeseries(act_pos3,time);
Y4=timeseries(act_pos4,time);
Y5=timeseries(act_pos5,time);
kk=0;
k=1;
model='Data_processing';
sim(model);
dys1=ans.dys1(1:NN,:);
dys2=ans.dys2(1:NN,:);
dy=[dys2,dys1];

dy1=dy(1:n1+n,:);
R1=(dy1'*dy1)/(n1+n);
RR1=(R1+kk*diag(diag(R1)));
invRR1=pinv(RR1);
dj=-((fol_err1(1:n1+n)'*dy1)/(n1+n))';
site=[P2;P3];
site1=site-k*invRR1*dj;

P2=site1(1);
P3=site1(2);

Gn=tf(1,[P1,P2,P3]);
Fr=1/Gn;
FrQ1=Fr*Q1;
FrQ1=c2d(FrQ1,0.0000625,'tustin');
[num_FrQ1,den_FrQ1]=tfdata(FrQ1,'v');