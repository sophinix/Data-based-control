A1=importdata('51.txt');
B1=A1.data;
fol_err1=B1(8:NN+7,4); %根据采样点范围，截取266个点，对应参考轨迹长度
J=CostComputation(fol_err1');
J1=CostComputation(fol_err1(1:n1)');
J2=CostComputation(fol_err1(n1+1:n2)');
J3=CostComputation(fol_err1(n2+1:n3)');
costJ=[J;J1;J2;J3];

k=1;
dj=-dy'*fol_err1(1:NN)/NN;
site=[P1;P2;P3;P4;P5;P6;P7;P8;P9];
site1=site-k*invRR1*dj;

P1=site1(1);
P2=site1(2);
P3=site1(3);
P4=site1(4);
P5=site1(5);
P6=site1(6);
P7=site1(7);
P8=site1(8);
P9=site1(9);
