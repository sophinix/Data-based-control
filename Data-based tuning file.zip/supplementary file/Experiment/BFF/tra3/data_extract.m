n1=101;
n2=164;%good
n3=257;
NN=n3;
n=0;
%Bumpless Filter
num_bump=[1 0.9355]*0.0117;
den_bump=[1 -1.8187 0.8187];
Q_BUMP=tf(num_bump,den_bump,0.0000625);

%Low pass filter
w=300;%rad/s
Q1=tf(w^2,[1 1.414*w w^2]);
Q1D=c2d(Q1,0.0000625,'tustin');
QCN=Q1D.Numerator{1,1};
QCD=Q1D.Denominator{1,1};

% 1/(1-Q) and Q/(1-Q) filter
Qy1=1/(1-Q1D);
[Qy1_num,Qy1_den]=tfdata(Qy1,'v');
Qy2=Q1D/(1-Q1D);
[Qy2_num,Qy2_den]=tfdata(Qy2,'v');
%magnification factor
mag_S1s3=0.0005;
mag_S1s2=0.25;
mag_S1s1=40;

mag_S2s3=0.0005;
mag_S2s2=2.5;
mag_S2s1=40;

mag_S3s3=0.0005;
mag_S3s2=0.25;
mag_S3s1=43;

P=3300;
I=3000;
D=15.311;
P1=0.000018661;
P2=0.1095;
P3=0.5656;
P4=0.000018661;
P5=0.1095;
P6=0.5656;
P7=0.000018661;
P8=0.1095;
P9=0.5656;

%其中一组数据act_pos 和 cmd_pos放反了。（正常：1时间，2cmdpos,3actpos,4error）
%initial_exp2 S1s3
A2=importdata('S1s3.txt');
B2=A2.data;
act_pos2=B2(8:NN+7,3);
%initial_exp3 S1s2
A3=importdata('S1s2.txt');
B3=A3.data; 
act_pos3=B3(7:NN+6,3);
%initial_exp2   
A4=importdata('S1s1.txt');
B4=A4.data;
act_pos4=B4(7:NN+6,3);

%initial_exp2 S2s3
A5=importdata('S2s3.txt');
B5=A5.data;
act_pos5=B5(7:NN+6,3);
%initial_exp3 S2s2
A6=importdata('S2s2.txt');
B6=A6.data; 
act_pos6=B6(7:NN+6,3);
%initial_exp2 S2s1
A7=importdata('S2s1.txt');
B7=A7.data;
act_pos7=B7(7:NN+6,3);

%initial_exp3 S3s3
A8=importdata('S3s3.txt');
B8=A8.data; 
act_pos8=B8(7:NN+6,3);
%initial_exp3 S3s2
A9=importdata('S3s2.txt');
B9=A9.data; 
act_pos9=B9(7:NN+6,3);
%initial_exp3 S3s1
A10=importdata('S3s1.txt');
B10=A10.data; 
act_pos10=B10(7:NN+6,3);

%exp1 Import error
A1=importdata('11.txt');
B1=A1.data;
fol_err1=B1(8:NN+7,4); %根据采样点范围，截取266个点，对应参考轨迹长度
time=B1(2:NN+1,1); %第一个点时间是0
J=CostComputation(fol_err1');
J1=CostComputation(fol_err1(1:n1)');
J2=CostComputation(fol_err1(n1+1:n2)');
J3=CostComputation(fol_err1(n2+1:n3)');
costJ=[J;J1;J2;J3];

S1s3=timeseries(act_pos2,time);
S1s2=timeseries(act_pos3,time);
S1s1=timeseries(act_pos4,time);

S2s3=timeseries(act_pos5,time);
S2s2=timeseries(act_pos6,time);
S2s1=timeseries(act_pos7,time);

S3s3=timeseries(act_pos8,time);
S3s2=timeseries(act_pos9,time);
S3s1=timeseries(act_pos10,time);

kk=0;
k=1;
model='Data_processing';
sim(model);

dyS1s3=ans.dyS1s3(1:NN,:);
dyS1s2=ans.dyS1s2(1:NN,:);
dyS1s1=ans.dyS1s1(1:NN,:);
dyS2s3=ans.dyS2s3(1:NN,:);
dyS2s2=ans.dyS2s2(1:NN,:);
dyS2s1=ans.dyS2s1(1:NN,:);
dyS3s3=ans.dyS3s3(1:NN,:);
dyS3s2=ans.dyS3s2(1:NN,:);
dyS3s1=ans.dyS3s1(1:NN,:);

dy=[dyS1s3,dyS1s2,dyS1s1,dyS2s3,dyS2s2,dyS2s1,dyS3s3,dyS3s2,dyS3s1];
dj=-dy'*fol_err1(1:NN)/NN;
R=dy'*dy/NN;
RR=(R+kk*diag(diag(R)));
invRR1=pinv(RR);
site=[P1;P2;P3;P4;P5;P6;P7;P8;P9];
site1=site-k*invRR1*dj;

P1=site1(1);
P2=site1(2);
P3=site1(3);
P4=site1(4);
P5=site1(5);
P6=site1(6);
P7=site1(7);
P8=site1(8);
P9=site1(9);