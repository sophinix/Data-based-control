The folder, "Experiment" has included all of the data of experiments and the MALTAB codes to realize the proposed method , M1 and M2. 

The folder, "simulation codes" contains the MALTAB and Simulink code to execute all simulation examples.