The folder "BFF" includes the simulation codes for tuning of bumpless feedforward controller(proposed method). 
In BFF, open "Tuning_of_BFF.m", set the trajectory, the length of it and the segmentation, the algorithm execute the optimization process with respect to the selected trajectory using M3. 
Open the folder "BFF_trajectory 5", the code "Tuning_of_BFF.m" can execute the optimization algorithm with respect to trajectory 5.

The folder "FF" includes the simulation codes for tuning of feedforward controller(M1). 
In FF, open "Tuning_of_FF.m", set the trajectory and the length of it , the algorithm can execute the optimziation process with respect to the selected trajectory using M1;

The folder "FFDOB" includes the simulation codes for tuning of bumpless feedforward controller(M2). 
In FFDOB, open "Tuning_of_FFDOB.m", set the trajectory and the length of it , the algorithm execute the optimziation process with respect to the selected trajectory using M2;

The folder "results" contains the simulation results of three methods across five trajectories.