size_mat=size(MAT);
num_plot=size_mat(1);
time=0:1:(i-1);
%parameters plot
figure(1)
if num_plot<7
for I=1:(num_plot-1)
    subplot((num_plot-1),1,I) 
plot(time,MAT(I,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$\rho_{1}$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:3:15]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0 1000]);
grid on
end
end

if num_plot>6
    row_plot=round((num_plot-1)/2);
for I=1:(num_plot-1)
    subplot(row_plot,2,I) 
plot(time,MAT(I,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
title('Controller parameter','fontsize',12,'FontName','微软雅黑');
% ylabel("$\rho$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:8:200]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[18 24]);
grid on
end
end

%error plot
figure(2)
plot(error);
title('Error Plot')
xlabel('Sampling point')
% ylabel('Tracking error (m)')
ylabel("e",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman')

%Plot of segment cost function
figure(3)
semilogy(time,MAT(num_plot,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Cost function','fontsize',12,'FontName','Arial');
% ylabel('$J$','Interpreter','latex' ,'fontsize',18,'FontName','Times new roman');
% xlabel('Iteration number','fontsize',12,'FontName','Arial');
title('Cost function','fontsize',12);
ylabel('$J$','Interpreter','latex' ,'fontsize',18);
xlabel('Iteration number','fontsize',12);
set(gca,'xtick',[0:1:15]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[18 24]);
grid on
