load('tra1.mat')% Trajectory 1
% load('tra2.mat')% Trajectory 2
% load('tra3.mat')% Trajectory 3
% load('tra5.mat')% Trajectory 5

%Collected total sampling points
N1=366;%change according to length of trajectory (trajectory 1 with N1 of 366 points becomes trajectory 4)
%Maximum number of iterations
num=10;
%Parameter table and Variation of cost function table
MAT=zeros(4,num);
%Initial six parameters
P=3300;
I=3000;
D=15.311;
P1=0.000018661;
P2=0.1095;
P3=0.5656;
%Define low passing filter
w=300;%rad/s
Q1=tf(w^2,[1 1.414*w w^2]);
Q1D=c2d(Q1,0.0000625);
QCN=Q1D.Numerator{1,1};
QCD=Q1D.Denominator{1,1};
%Add initial parameters in table
MAT(1,1)=P1;
MAT(2,1)=P2;
MAT(3,1)=P3;
for i = 1:num
%Define disturbance observer
Gn=tf(1,[P1,P2,P3]);
Fr=1/Gn;
FrQ1=Fr*Q1;
FrQ1=c2d(FrQ1,0.0000625);
[num_FrQ1,den_FrQ1]=tfdata(FrQ1,'v');

syscf=tf([1,0],[P1,P2,P3+D,P,I]);
sysdcf=c2d(syscf,0.0000625);
cfn=sysdcf.Numerator{1,1};
cfd=sysdcf.Denominator{1,1};
%Get tracking error
model='IFT_FFDOB';
sim(model);
dy=ans.dy(1:N1,:);
error=(ans.error(1:N1))';
je=(error*error')/(2*N1);

%stop criterion
if i>1
if (jeold-je)/jeold<0.05
    break
end
end
%data storation
jeold=je; 

%Data-processing
dj=[(error*(-dy))/N1]';
%Hessian matrix
R=(dy'*dy)/N1;
invR=pinv(R);
k=1;
site=[P1;P2;P3];
%Update parameters
site2=site-k*invR*dj;
P1=site2(1);
P2=site2(2);
P3=site2(3);
MAT(1,i+1)=P1;
MAT(2,i+1)=P2;
MAT(3,i+1)=P3;
MAT(4,i)=je;
end
model='IFT_FFDOB';
sim(model);
error=(ans.error(1:N1))';
j=(error*error')/(2*N1);
MAT(4,i)=je;
MATffdob=MAT;
errorffdob=error;
run("Plot_3_fixed_gain.m")