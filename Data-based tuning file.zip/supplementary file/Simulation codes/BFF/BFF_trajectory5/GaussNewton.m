function thetaoptimized=GaussNewton(theta,stepsize,Hessian,grad)
thetaoptimized=theta-stepsize*pinv(Hessian)*grad;
end