MAT_2paras=[MAT(2:3,:);MAT(5:6,:);MAT(8:10,:)];
num_plot=size(MAT_2paras,1);
time=0:1:(i-1);
%parameters plot
figure(1)
% if num_plot>6
%     row_plot=round((num_plot-1)/2);
% for I=1:(num_plot-1)
%     subplot(row_plot,2,I) 
% plot(time,MAT_2paras(I,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
% set(gca,'FontSize',14)
% set(gca, 'Box', 'on', ...                                         % 边框
%          'LineWidth', 1,...                                       % 线宽
%          'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
%          'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
%          'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
%          'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
% % ylabel("$\rho$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman');
% %xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
% set(gca,'xtick',[0:8:200]); %头尾，隔三个
% % set(gca,'XLim',[0 15]);
% % set(gca,'ytick',[18:3:24]);%头尾，隔三个
% % set(gca,'YLim',[18 24]);
% grid on
% end
% end
subplot(3,2,1)
plot(time,MAT_2paras(1,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$P_{11}$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
% xlabel('Iteration Number','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'XLim',[1 5]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.1095 0.112]);
grid on

subplot(3,2,2)
plot(time,MAT_2paras(2,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$$P_{12}$$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.5 1.5]);
grid on

subplot(3,2,3)
plot(time,MAT_2paras(3,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$$P_{21}$$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.1 0.2]);
grid on

subplot(3,2,4)
plot(time,MAT_2paras(4,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$$P_{22}$$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.4 0.6]);
grid on

subplot(3,2,5)
plot(time,MAT_2paras(5,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$$P_{31}$$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.1095 0.12]);
grid on

subplot(3,2,6)
plot(time,MAT_2paras(6,1:i),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
% title('Controller parameter','fontsize',12,'FontName','微软雅黑');
ylabel("$$P_{32}$$",'Interpreter','latex' ,'fontsize',14,'FontName','Times new roman');
%xlabel('迭代次数(次)','fontsize',12,'FontName','微软雅黑');
set(gca,'xtick',[0:1:200]); %头尾，隔三个
% set(gca,'XLim',[0 15]);
% set(gca,'ytick',[18:3:24]);%头尾，隔三个
% set(gca,'YLim',[0.5 1.5]);
grid on


%error plot
figure(2)
xs1=1:n1;
xs2=n1+1:n2;
xs3=n2+1:n3;
error1=error1(1:n1);
error2=error2(1:n2-n1);
error3=error3(1:n3-n2);
subplot(4,1,1)
plot(error);
title('Error Plot')
xlabel('Sampling point')
% ylabel('Tracking error (m)')
ylabel("e",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman')
subplot(4,1,2)
plot(xs1,error1);
title('Error Plot1')
xlabel('Sampling point')
ylabel("$e_{1}$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman')
subplot(4,1,3)
plot(xs2,error2);
title('Error Plot2')
xlabel('Sampling point')
ylabel("$e_{2}$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman')
figure(2)
subplot(4,1,4)
plot(xs3,error3);
title('Error Plot3')
xlabel('Sampling point')
ylabel("$e_{3}$",'Interpreter','latex' ,'fontsize',18,'FontName','Times new roman')
%Plot of segment cost function
figure(3) 
semilogy(time,MAT(size(MAT,1),1:i)*(10^6),'--o','Color',[0.49 0.18 0.56],'LineWidth',1.5,'MarkerSize',7,'MarkerFaceColor','c');
set(gca,'FontSize',14)
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1]);   
title('Cost function','fontsize',12,'FontName','微软雅黑');
ylabel('$J(\mathrm{mm}^2)$','Interpreter','latex' ,'fontsize',18,'FontName','Times new roman');
set(gca,'xtick',[0:1:15]); %头尾，隔三个


