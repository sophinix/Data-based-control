%Input trajectory
load('tra5.mat')
%Collected total sampling points
N1=528;
%Maximum number of iterations
num=10;
n=0;
%Parameter table and Variation of cost function table
MAT=zeros(19,num);
MAT1=zeros(3,num);

%Start points of each segment
n1=105; %first segmentation
n2=164; %second segmentation
n3=269; %third segmentation
n4=368; %fourth segmentation
n5=427; %fifth segmentation
n6=528;

%Scaling factors
mag_S1s3=0.0005;
mag_S1s2=0.25;
mag_S1s1=40;
mag_S2s3=0.0005;
mag_S2s2=2.5;
mag_S2s1=40;
mag_S3s3=0.0005;
mag_S3s2=0.25;
mag_S3s1=43;
mag_S4s3=0.0005;
mag_S4s2=0.25;
mag_S4s1=40;
mag_S5s3=0.0005;
mag_S5s2=2.5;
mag_S5s1=40;
mag_S6s3=0.0005;
mag_S6s2=0.25;
mag_S6s1=43;

%Initial parameters of feedback controller
P=3300;
I=3000;
D=15.311;

%initial parameters of feedforward controller
P1=0.000018661;
P2=0.1095;
P3=0.5656;

%Define low passing filter
w=300;%rad/s
[QCN,QCD,Q1D,Q1]=ButterWorth(300,0.0000625);

% 1/(1-Q) filter
Qy1=1/(1-Q1D);
[Qy1_num,Qy1_den]=tfdata(Qy1,'v');
Qy2=Q1D/(1-Q1D);
[Qy2_num,Qy2_den]=tfdata(Qy2,'v');

%Add initial parameters in table
MAT(1,1)=P1;
MAT(2,1)=P2;
MAT(3,1)=P3;
MAT(4,1)=P1;
MAT(5,1)=P2;
MAT(6,1)=P3;
MAT(7,1)=P1;
MAT(8,1)=P2;
MAT(9,1)=P3;
MAT(10,1)=P1;
MAT(11,1)=P2;
MAT(12,1)=P3;
MAT(13,1)=P1;
MAT(14,1)=P2;
MAT(15,1)=P3;
MAT(16,1)=P1;
MAT(17,1)=P2;
MAT(18,1)=P3;


%Initial parameters of 2nd,3rd segments
P4=MAT(4,1);
P5=MAT(5,1);
P6=MAT(6,1);
P7=MAT(7,1);
P8=MAT(8,1);
P9=MAT(9,1);
P10=MAT(10,1);
P11=MAT(11,1);
P12=MAT(12,1);
P13=MAT(13,1);
P14=MAT(14,1);
P15=MAT(15,1);
P16=MAT(16,1);
P17=MAT(17,1);
P18=MAT(18,1);

%set step size 
k=1; 
%disturbance observer
[num_FrQ1,den_FrQ1]=DOBQF(0.000018661,0.1095,0.5656,Q1,0.0000625);
[num_FrQ12,den_FrQ12]=DOBQF(0.000018661,0.1095,0.5656,Q1,0.0000625);
[num_FrQ13,den_FrQ13]=DOBQF(0.000018661,0.1095,0.5656,Q1,0.0000625);

%perturbation exp
model1='perturbationfb';
sim(model1);
%Extract output gradient
dy1=ans.dy1(1:N1,:);
dy2=ans.dy2(1:N1,:);
dy3=ans.dy3(1:N1,:);
dy4=ans.dy4(1:N1,:);
dy5=ans.dy5(1:N1,:);
dy6=ans.dy6(1:N1,:);
dy=[dy1,dy2,dy3,dy4,dy5,dy6];

for i = 1:num
%Get tracking error
model='BFFfb';
sim(model);
error=(ans.error(1:N1))';
je=(error*error')/(2*N1);
MAT(19,i)=je;

error1=error(1:n1);
error2=error(n1+1:n2);
error3=error(n2+1:n3);
je1=(error1*error1')/(2*n1);
je2=(error2*error2')/(2*(n2-n1));
je3=(error3*error3')/(2*(n3-n2));                                                                                                            
MAT1(1,i)=je1;
MAT1(2,i)=je2;
MAT1(3,i)=je3;

%stop criterion
if i>1
if (jeold-je)/jeold<0.05
    break
end
end
%data storation
jeold=je;
je1old=je1;
%get the cost function gradient
dj1=(error*(-dy1))'/N1;
dj2=(error*(-dy2))'/N1;
dj3=(error*(-dy3))'/N1;
dj4=(error*(-dy4))'/N1;
dj5=(error*(-dy5))'/N1;
dj6=(error*(-dy6))'/N1;

dj=[dj1;dj2;dj3;dj4;dj5;dj6];
%Hessian matrix
R=dy'*dy/N1;
theta1=[P1;P2;P3;P4;P5;P6;P7;P8;P9;P10;P11;P12;P13;P14;P15;P16;P17;P18];
%Update parameters
theta=GaussNewton(theta1,k,R,dj);
P1=theta(1);
P2=theta(2);
P3=theta(3);
P4=theta(4);
P5=theta(5);
P6=theta(6);
P7=theta(7);
P8=theta(8);
P9=theta(9);
P10=theta(10);
P11=theta(11);
P12=theta(12);
P13=theta(13);
P14=theta(14);
P15=theta(15);
P16=theta(16);
P17=theta(17);
P18=theta(18);
%Add value in table
MAT(1,i+1)=P1;
MAT(2,i+1)=P2;
MAT(3,i+1)=P3;
MAT(4,i+1)=P4;
MAT(5,i+1)=P5;
MAT(6,i+1)=P6;
MAT(7,i+1)=P7;
MAT(8,i+1)=P8;
MAT(9,i+1)=P9;
MAT(10,i+1)=P10;
MAT(11,i+1)=P11;
MAT(12,i+1)=P12;
MAT(13,i+1)=P13;
MAT(14,i+1)=P14;
MAT(15,i+1)=P15;
MAT(16,i+1)=P16;
MAT(17,i+1)=P17;
MAT(18,i+1)=P18;
end
if i==num
%define DOB
model='BFFfb';
sim(model);
error=(ans.error(1:N1))';
je=(error*error')/(2*N1);
error1=error(1:n1);
error2=error(n1+1:n2);
error3=error(n2+1:n3);
je1=CostComputation(error1);
je2=CostComputation(error2);
je3=CostComputation(error3);
MAT(19,i+1)=je;
MAT1(1,i)=je1;
MAT1(2,i)=je2;
MAT1(3,i)=je3;
end
MATbff=MAT;
errorbff=error;