function [num,den,FilterD,Q]=ButterWorth(w,s)
Q=tf(w^2,[1 1.414*w w^2]);
FilterD=c2d(Q,s);
num=FilterD.Numerator{1,1};
den=FilterD.Denominator{1,1};
end