function ts=TimeSeries(vector)
    interval=0:0.0000625:0.0000625*(size(vector)-1);
    ts=timeseries(vector,interval);
end