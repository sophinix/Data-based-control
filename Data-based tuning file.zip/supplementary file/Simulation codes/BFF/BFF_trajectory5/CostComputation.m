function J=CostComputation(error)
J=error*error'/(2*size(error,2));
end