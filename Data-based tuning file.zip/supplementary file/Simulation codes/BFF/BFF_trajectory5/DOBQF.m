function [num,den]=DOBQF(P1,P2,P3,Q,s)
Gn=tf(1,[P1,P2,P3]);
F=1/Gn;
FQ=F*Q;
FQD=c2d(FQ,s);
[num,den]=tfdata(FQD,'v');
end